document.addEventListener("DOMContentLoaded", () => {
    const rules = document.querySelectorAll('.rule');
    let delay = 200;

    rules.forEach((rule, index) => {
        setTimeout(() => {
            rule.style.opacity = "1";
            rule.style.transform = "translateY(0)";
        }, index * delay);
    });
});
